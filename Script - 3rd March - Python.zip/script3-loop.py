
alpha= ['web-server1','db-server1','web-server2','db-server2','we-server3']

for beta in alpha:
     if beta.startswith('web'):
          print('web server')
     else:
          print('db server')
          
          


     
     
