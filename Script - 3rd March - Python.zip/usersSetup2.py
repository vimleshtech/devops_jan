f = open(r'C:\Users\vkumar15\Desktop\today\users2.txt','r') #r - read


us = f.readlines()
print(us)

for u in us:
     items=u.split(',')# [user1,add,rw]
     action= items[1].lower().strip()
     
     if action =='add':          
     
          print('users action  add ',items[0],'-',items[2])
          
     elif action=='remove':

               print('users action  remove ',items[0])
     elif action =='modify':

               print('users action  modify ',items[0],'-',items[2])
     else:
          print('not match')



