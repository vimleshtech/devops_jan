f = open(r'C:\Users\vkumar15\Desktop\today\users.txt','r') #r - read
#read() : read all content
#readline()  : read line by line 
#readlines()  : read all lines and convert/store on list 

#print(f.read())

#print(f.readline())
#print(f.readline())


us = f.readlines()
#print(us)

for u in us:
     #print('add user  - ',u)
     print('add user  - ',u.replace('\n',''))



