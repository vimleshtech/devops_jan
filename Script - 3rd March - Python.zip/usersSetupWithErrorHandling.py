
f = open(r'C:\Users\vkumar15\Desktop\today\users2.txt','r') #r - read


us = f.readlines()
print(us)

o = open(r'C:\Users\vkumar15\Desktop\today\logs.txt','a') #w

for u in us:
     items=u.split(',')# [user1,add,rw]
     action= items[1].lower().strip()

     try:
          if action =='add':          
          
               print('users action  add ',items[0],'-',items[20])
               
          elif action=='remove':

                    print('users action  remove ',items[0])
          elif action =='modify':

                    print('users action  modify ',items[0],'-',items[2])
          else:
               print('not match')
     except IndexError as e:
          o.write(items[0]+' : failed '+str(e)+'\n')
     except:
          print('fail')
          o.write(items[0]+' : failed \n')



o.close()



          

