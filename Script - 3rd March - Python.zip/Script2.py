
servers = ['web-server1','db-server1','web-server2','db-server2','we-server3']

#if without else
if 'web-server1' in servers:
     print('match')


#install jdk
     

#if else 
if 'web-server1' in servers:
     print('match')
     print('match')
     print('match')
     print('match')
     print('match')
     print('match')
     print('match')
     print('match')
     print('match')
     print('match')
else:
     print('no match')

#if elif elf ...else / ladder if else
     
if 'db-server2' in servers:
     print('db server is match')
elif 'db-server3' in servers:
     print('test')
elif 'db-server3' in servers:
     print('test')
elif 'db-server3' in servers:
     print('test')
else:
     print('other')
     


     



